package com.example.carwoaw;

import com.google.firebase.database.Exclude;

public class Upload {
    private String mName;
    private String mEngine;
    private String mMileage;
    private String mPrice;
    private String mDate;
    private String mOwner;
    private String mImageUrl;
    private String mCode;
    private String mKey;
    private String fav;
    private String mTrackID;
    private String mType;
    private String mTypePos;

    public Upload() {
        //empty needed
    }

    public Upload(String name, String engine, String mileage, String price, String date, String owner, String favStat, String imageUrl, String code, String trackID, String type, String pos) {
        if (name.trim().equals("")) {
            name = "Unknown Car";
        }
        mName = name;
        mEngine = engine;
        mMileage = mileage;
        mPrice = price;
        mDate = date;
        mOwner = owner;
        mImageUrl = imageUrl;
        mCode = code;
        fav = favStat;
        mTrackID = trackID;
        mType = type;
        mTypePos = pos;
    }

    public String getName() {
        return mName;
    }

    public void setName(String name) {
        mName = name;
    }

    public String getEngine() {
        return mEngine;
    }

    public void setEngine(String engine) {
        mEngine = engine;
    }

    public String getMileage() {
        return mMileage;
    }

    public String getPrice() {
        return mPrice;
    }

    public void setPrice(String price) {
        mPrice = price;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date) {
        mDate = date;
    }

    public String getOwner() {
        return mOwner;
    }

    public void setOwner(String owner) {
        mOwner = owner;
    }

    public void setMileage(String mileage) {
        mMileage = mileage;
    }

    public String getImageUrl() {
        return mImageUrl;
    }

    public void setImageUrl(String imageUrl) {
        mImageUrl = imageUrl;
    }

    public String getCode() {
        return mCode;
    }

    public void setCode(String code) {
        mCode = code;
    }

    public String getFav() {
        return fav;
    }

    public void setFav(String fav) {
        this.fav = fav;
    }

    public String getTrackID() {
        return mTrackID;
    }

    public void setTrackID(String trackID) {
        mTrackID = trackID;
    }

    public String getType() {
        return mType;
    }

    public void setType(String type) {
        mType = type;
    }

    public String getTypePos() {
        return mTypePos;
    }

    public void setTypePos(String typePos) {
        mTypePos = typePos;
    }

    //exclude from firebase because already have the key
    @Exclude
    public String getKey() {
        return mKey;
    }

    @Exclude
    public void setKey(String key) {
        mKey = key;
    }
}
