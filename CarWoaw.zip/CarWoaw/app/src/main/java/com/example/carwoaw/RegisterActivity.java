package com.example.carwoaw;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegisterActivity extends AppCompatActivity {
    EditText mFullName, mPhone, mPassword, mEmail;
    String rbGender;
    TextView LoginBtn;
    Button RegisterBtn;
    FirebaseAuth fAuth;
    ProgressBar progressBar;
    long maxID;

    DatabaseReference node;
    FirebaseDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        mFullName = findViewById(R.id.name);
        mPhone = findViewById(R.id.phone);
        mPassword = findViewById(R.id.password);
        mEmail = findViewById(R.id.email);
        LoginBtn = findViewById(R.id.login_link);
        RegisterBtn = findViewById(R.id.register_btn);
        progressBar = findViewById(R.id.progressBar);
        fAuth = FirebaseAuth.getInstance();

        if (fAuth.getCurrentUser()!=null) {
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
            finish();
        }

        db = FirebaseDatabase.getInstance();
        node = db.getReference().child("profile");
        node.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                maxID = (dataSnapshot.getChildrenCount());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        RegisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = mFullName.getText().toString().trim();
                String phone = mPhone.getText().toString().trim();
                String gender = rbGender;
                String password = mPassword.getText().toString().trim();
                String email = mEmail.getText().toString().trim();

                profile pro = new profile(name, phone, gender, email, password);

                node.child(password).setValue(pro);

                if (TextUtils.isEmpty(email)) {
                    mEmail.setError("Email is required!");
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    mPassword.setError("Password is required!");
                    return;
                }
                if(password.length()<6) {
                    mPassword.setError("Password must be greater than 6 character");
                    return;
                }
                progressBar.setVisibility(View.VISIBLE);
                //Register data
                fAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(RegisterActivity.this, "User Registered!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                            finish();
                        }
                        else {
                            Toast.makeText(RegisterActivity.this, "Error!" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            progressBar.setVisibility(View.GONE);
                        }
                    }
                });
            }
        });

        LoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
            }
        });

    }

    public void genderOnclick(View view) {
        //check if radio button is clicked
        boolean checked = ((RadioButton) view).isChecked();

        //check which radio button is clicked
        switch (view.getId()) {
            case R.id.male:
                if (checked) {
                    rbGender = "Male";
                    Toast.makeText(RegisterActivity.this, "Male selected!", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.female:
                if (checked) {
                    rbGender = "Female";
                    Toast.makeText(RegisterActivity.this, "Female selected!", Toast.LENGTH_SHORT).show();
                }
        }
    }
}