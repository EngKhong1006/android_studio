package com.example.carwoaw;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FavImageAdapter extends RecyclerView.Adapter<FavImageAdapter.ImageViewHolder>  {

    private Context mContext;
    private static List<Upload> mUploads;
    private OnFavListener mOnItemListener;

    public FavImageAdapter(Context context, List<Upload> uploads, OnFavListener onItemListener) {
        mContext = context;
        mUploads = uploads;
        this.mOnItemListener = onItemListener;
    }

    @NonNull
    @Override
    public FavImageAdapter.ImageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.image_item, parent, false);
        return new ImageViewHolder(v, mOnItemListener);
    }

    @Override
    public void onBindViewHolder(@NonNull FavImageAdapter.ImageViewHolder holder, int position) {
        Upload uploadCurrent = mUploads.get(position);
        holder.textViewName.setText(uploadCurrent.getName());
        holder.textViewOwner.setText("By: " + uploadCurrent.getOwner());
        Picasso.get()
                .load(uploadCurrent.getImageUrl())
                .fit()
                .centerCrop()
                .into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return mUploads.size();
    }

    public class ImageViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView textViewName;
        public TextView textViewOwner;
        public ImageView imageView;
        public Button favBtn;
        OnFavListener mOnItemListener;

        public ImageViewHolder(@NonNull View itemView, OnFavListener onItemListener) {
            super(itemView);

            textViewName = itemView.findViewById(R.id.text_view_name);
            textViewOwner = itemView.findViewById(R.id.text_view_owner);
            imageView = itemView.findViewById(R.id.image_view_upload);
            favBtn = itemView.findViewById(R.id.fav_button);

            favBtn.setBackgroundResource(R.drawable.ic_baseline_favorite_red);

            this.mOnItemListener = onItemListener;

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            if (mOnItemListener != null) {
                int position = getAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    mOnItemListener.onItemClick(position);
                }
            }
        }
    }

    public interface OnFavListener {
        void onItemClick(int position);
    }

}
