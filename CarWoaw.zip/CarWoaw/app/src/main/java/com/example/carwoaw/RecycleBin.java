package com.example.carwoaw;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

import static com.example.carwoaw.HomeFragment.EXTRA_CODE;
import static com.example.carwoaw.HomeFragment.EXTRA_DATE;
import static com.example.carwoaw.HomeFragment.EXTRA_ENGINE;
import static com.example.carwoaw.HomeFragment.EXTRA_MILEAGE;
import static com.example.carwoaw.HomeFragment.EXTRA_MODEL;
import static com.example.carwoaw.HomeFragment.EXTRA_OWNER;
import static com.example.carwoaw.HomeFragment.EXTRA_PRICE;
import static com.example.carwoaw.HomeFragment.EXTRA_TRACK_ID;
import static com.example.carwoaw.HomeFragment.EXTRA_URL;
import static com.example.carwoaw.HomeFragment.EXTRA_POSITION;

public class RecycleBin extends AppCompatActivity implements RecycleBinAdapter.OnItemClickListener {

    private RecyclerView mRecyclerView;
    private RecycleBinAdapter mAdapter;
    private TextView binText;

    private FirebaseStorage mStorage;
    private DatabaseReference mDatabaseRef;
    private ValueEventListener mDBListener;
    private List<Upload> mUploads;
    String text2;
    long num = 0;

    String binName, binEngine, binPrice, binMileage, binDate, binOwner, binStat, binImg, binCode, binTrackID, binType, binPos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycle_bin);

        setTitle("Recycle Bin");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle result2 = MainActivity.getPc();
        text2 = result2.getString("pw");

        mRecyclerView = findViewById(R.id.recycler_view_bin);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        mUploads = new ArrayList<>();

        mAdapter = new RecycleBinAdapter(RecycleBin.this, mUploads);

        mAdapter.setOnItemClickListener(RecycleBin.this);

        mRecyclerView.setAdapter(mAdapter);

        mStorage = FirebaseStorage.getInstance();
        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("recycle-bin");
        mDBListener = mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                num = (dataSnapshot.getChildrenCount());
                binText = findViewById(R.id.no_post_list_bin);

                if (num != 0) {
                    binText.setText("Recently deleted post");
                    mUploads.clear();

                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        Upload upload = postSnapshot.getValue(Upload.class);
                        upload.setKey(postSnapshot.getKey());
                        mUploads.add(upload);
                    }

                    mAdapter.notifyDataSetChanged();
                } else {
                    binText.setText("No deleted post currently");
                    mUploads.clear();
                    mAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onItemClick(int position) {
        Toast.makeText(this, "Long click for menu at post " + (position+1), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onRecoverClick(int position) {
        Upload selectedItem = mUploads.get(position);
        final String selectedKey = selectedItem.getKey();

        Upload clickedItem = mUploads.get(position);

        binImg = clickedItem.getImageUrl();
        binName = clickedItem.getName();
        binEngine = clickedItem.getEngine();
        binMileage = clickedItem.getMileage();
        binPrice = clickedItem.getPrice();
        binDate = clickedItem.getDate();
        binOwner = clickedItem.getOwner();
        binStat = clickedItem.getFav();
        binCode = clickedItem.getCode();
        binTrackID = clickedItem.getTrackID();
        binType = clickedItem.getType();
        binPos = clickedItem.getTypePos();

        DatabaseReference uploadsDB = FirebaseDatabase.getInstance().getReference().child("uploads").child(text2);
        DatabaseReference uploads2DB = FirebaseDatabase.getInstance().getReference().child("uploads2");

        Upload recover = new Upload(binName, binEngine, binMileage, binPrice, binDate, binOwner, binStat, binImg, binCode, binTrackID, binType, binPos);
        uploadsDB.child(selectedKey).setValue(recover);
        uploads2DB.child(binTrackID).setValue(recover);
        mDatabaseRef.child(selectedKey).removeValue();
        Toast.makeText(RecycleBin.this, "Post has been recovered!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDeleteClick(final int position) {
        Upload selectedItem = mUploads.get(position);
        final String selectedKey = selectedItem.getKey();
        mDatabaseRef.child(selectedKey).removeValue();

        StorageReference imageRef = mStorage.getReferenceFromUrl(selectedItem.getImageUrl());
        imageRef.delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void aVoid) {
                Toast.makeText(RecycleBin.this, "Post deleted forever!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDatabaseRef.removeEventListener(mDBListener);
    }

    @Override
    public boolean onSupportNavigateUp() {
        navigateUpTo(new Intent(getBaseContext(), MainActivity.class));
        return true;
    }
}