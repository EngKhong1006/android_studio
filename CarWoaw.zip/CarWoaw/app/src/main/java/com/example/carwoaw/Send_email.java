package com.example.carwoaw;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintJob;
import android.print.PrintManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;

import static com.example.carwoaw.HomeFragment.EXTRA_URL;
import static com.example.carwoaw.SelectedItemActivity.EXTRA_EMAIL_FROM;
import static com.example.carwoaw.SelectedItemActivity.EXTRA_EMAIL_TO;
import static com.example.carwoaw.SelectedItemActivity.EXTRA_IMG;
import static com.example.carwoaw.SelectedItemActivity.EXTRA_TITLE;

public class Send_email extends AppCompatActivity {

    private TextView mEmailTo;
    private TextView mEmailFrom;
    private TextView mEmailTitle;
    private ImageView mEmailImage;
    private EditText mEmailContext;
    private Button mEmailSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_email);

        setTitle("Send Email");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mEmailTo = findViewById(R.id.emailTo);
        mEmailFrom = findViewById(R.id.emailFrom);
        mEmailTitle = findViewById(R.id.title);
        mEmailImage = findViewById(R.id.send_img);
        mEmailContext = findViewById(R.id.edit_text_content);
        mEmailSend = findViewById(R.id.email_sendTO);

        Intent intent = getIntent();
        final String imageUrl = intent.getStringExtra(EXTRA_IMG);
        final String to = intent.getStringExtra(EXTRA_EMAIL_TO);
        final String from = intent.getStringExtra(EXTRA_EMAIL_FROM);
        final String ti = intent.getStringExtra(EXTRA_TITLE);

        Picasso.get().load(imageUrl).fit().centerInside().into(mEmailImage);
        mEmailTo.setText(to);
        mEmailFrom.setText(from);
        mEmailTitle.setText(ti);

        final Uri getImg = Uri.parse(imageUrl);

        mEmailSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                intent.putExtra(Intent.EXTRA_SUBJECT, ti);
                intent.putExtra(Intent.EXTRA_STREAM, getImg);
                intent.putExtra(Intent.EXTRA_TEXT, mEmailContext.getText().toString());
                intent.setType("image/png");
                startActivity(Intent.createChooser(intent,"Choose Mail App"));
            }
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        navigateUpTo(new Intent(getBaseContext(), SelectedItemActivity.class));
        return true;
    }
}