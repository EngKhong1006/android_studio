package com.example.carwoaw;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

import static android.content.ContentValues.TAG;
import static com.example.carwoaw.HomeFragment.EXTRA_CODE;
import static com.example.carwoaw.HomeFragment.EXTRA_DATE;
import static com.example.carwoaw.HomeFragment.EXTRA_ENGINE;
import static com.example.carwoaw.HomeFragment.EXTRA_MILEAGE;
import static com.example.carwoaw.HomeFragment.EXTRA_MODEL;
import static com.example.carwoaw.HomeFragment.EXTRA_OWNER;
import static com.example.carwoaw.HomeFragment.EXTRA_POS;
import static com.example.carwoaw.HomeFragment.EXTRA_PRICE;
import static com.example.carwoaw.HomeFragment.EXTRA_TRACK_ID;
import static com.example.carwoaw.HomeFragment.EXTRA_TYPE;
import static com.example.carwoaw.HomeFragment.EXTRA_URL;
import static com.example.carwoaw.HomeFragment.EXTRA_POSITION;

public class EditActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private static final int RESULT_OK = -1;

    final Calendar myCalendar = Calendar.getInstance();

    private Button mButtonChooseImage;
    private Button mButtonUpload;
    private Button mButtonDate;
    private EditText mEditTextFileName;
    private EditText mEditTextEngine;
    private EditText mEditTextMileage;
    private EditText mEditTextPrice;
    private TextView mTextViewDate;
    private TextView mTextViewOwner;
    private ImageView mImageView;
    private TextView mFavStatus;
    private ProgressBar mProgressBar;
    private Spinner mEditSpinner;
    String getPosition;
    String getImg;
    String text2;
    String getTrackID;
    String getType;
    String vehicleType;
    int imgPicked = 0;
    String typePosition;

    private Uri mImageUri;
    private Uri downloadUri;

    private StorageReference mStorageRef;
    private DatabaseReference mDatabaseRef;
    private DatabaseReference mDatabaseRef2;

    private Task<Uri> mUploadTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        setTitle("Edit Post");

        Bundle result2 = MainActivity.getPc();
        text2 = result2.getString("pw");

        mButtonChooseImage = findViewById(R.id.update_button_choose_image);
        mButtonUpload = findViewById(R.id.update_button_upload);
        mButtonDate = findViewById(R.id.update_date_btn);
        mEditTextFileName = findViewById(R.id.update_text_file_name);
        mEditTextEngine = findViewById(R.id.update_text_engine);
        mEditTextMileage = findViewById(R.id.update_text_mileage);
        mEditTextPrice = findViewById(R.id.update_text_price);
        mTextViewDate = findViewById(R.id.update_view_date);
        mTextViewOwner = findViewById(R.id.update_owner_email);
        mEditSpinner = findViewById(R.id.edit_spinner_car_type);

        Intent intent = getIntent();

        getImg = intent.getStringExtra(EXTRA_URL);
        mEditTextFileName.setText(intent.getStringExtra(EXTRA_MODEL));
        mEditTextEngine.setText(intent.getStringExtra(EXTRA_ENGINE));
        mEditTextMileage.setText(intent.getStringExtra(EXTRA_MILEAGE));
        mEditTextPrice.setText(intent.getStringExtra(EXTRA_PRICE));
        mTextViewDate.setText(intent.getStringExtra(EXTRA_DATE));
        mTextViewOwner.setText(intent.getStringExtra(EXTRA_OWNER));
        getPosition = intent.getStringExtra(EXTRA_POSITION);
        text2 = intent.getStringExtra(EXTRA_CODE);
        getTrackID = intent.getStringExtra(EXTRA_TRACK_ID);
        getType = (intent.getStringExtra(EXTRA_TYPE));
        typePosition = intent.getStringExtra(EXTRA_POS);

        mImageView = findViewById(R.id.update_image_view);
        Picasso.get().load(getImg).fit().centerInside().into(mImageView);
        mFavStatus = findViewById(R.id.fav_status);
        mProgressBar = findViewById(R.id.update_progress_bar);

        mEditSpinner.setSelection(Integer.parseInt(typePosition));
        mEditSpinner.setOnItemSelectedListener(new SpinnerTypeListener());
        getType = mEditSpinner.getSelectedItem().toString();
        typePosition = String.valueOf(mEditSpinner.getSelectedItemPosition());

        mStorageRef = FirebaseStorage.getInstance().getReference("uploads");
        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("uploads").child(text2);
        mDatabaseRef2 = FirebaseDatabase.getInstance().getReference().child("uploads2");

        final DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {

            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
        };

        mButtonDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                new DatePickerDialog(getApplicationContext(), date, myCalendar
                        .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH)).show();
            }
        });

        mButtonChooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser();
            }
        });

        mButtonUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mUploadTask != null) {
                    Toast.makeText(getApplicationContext(), "Upload in progress", Toast.LENGTH_SHORT).show();
                } else {
                    if (mEditTextFileName.length() > 0) {
                        if (mEditTextEngine.length() > 0) {
                            if (mEditTextMileage.length() > 0) {
                                if (mEditTextPrice.length() > 0) {
                                    if (imgPicked == 1) {
                                        uploadFile();
                                    } else {
                                        Upload upload = new Upload(mEditTextFileName.getText().toString().trim(),
                                                mEditTextEngine.getText().toString().trim(),
                                                mEditTextMileage.getText().toString().trim(),
                                                mEditTextPrice.getText().toString().trim(),
                                                mTextViewDate.getText().toString().trim(),
                                                mTextViewOwner.getText().toString().trim(),
                                                mFavStatus.getText().toString().trim(),
                                                getImg,
                                                text2,
                                                getTrackID,
                                                getType,
                                                typePosition);

                                        String uploadId = getPosition;
                                        mDatabaseRef.child(uploadId).setValue(upload);
                                        mDatabaseRef2.child(getTrackID).setValue(upload);
                                        Toast.makeText(getApplicationContext(), "Update successful", Toast.LENGTH_SHORT).show();
                                    }
                                    openImagesActivity();
                                } else {
                                    Toast.makeText(getApplicationContext(), "Please fill-in vehicle price", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(getApplicationContext(), "Please fill-in vehicle mileage", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(getApplicationContext(), "Please fill-in vehicle engine", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(getApplicationContext(), "Please fill-in vehicle name", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void  openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            mImageUri = data.getData();
            Picasso.get().load(mImageUri).into(mImageView);
            imgPicked = 1;
        }
    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }

    private void uploadFile() {
        if (mImageUri != null)
        {
            final StorageReference fileReference = mStorageRef.child(System.currentTimeMillis()
                    + "." + getFileExtension(mImageUri));

            mUploadTask =  fileReference.putFile(mImageUri).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>()
            {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception
                {
                    if (!task.isSuccessful())
                    {
                        throw task.getException();
                    }
                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>()
            {
                @Override
                public void onComplete(@NonNull Task<Uri> task)
                {
                    if (task.isSuccessful())
                    {
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                mProgressBar.setProgress(0);
                            }
                        }, 5000);
                        downloadUri = task.getResult();
                        Log.e(TAG, "then: " + downloadUri.toString());
                        Upload upload = new Upload(mEditTextFileName.getText().toString().trim(),
                                mEditTextEngine.getText().toString().trim(),
                                mEditTextMileage.getText().toString().trim(),
                                mEditTextPrice.getText().toString().trim(),
                                mTextViewDate.getText().toString().trim(),
                                mTextViewOwner.getText().toString().trim(),
                                mFavStatus.getText().toString().trim(),
                                downloadUri.toString(),
                                text2,
                                getTrackID,
                                getType,
                                typePosition);

                        String uploadId = getPosition;
                        mDatabaseRef.child(uploadId).setValue(upload);
                        mDatabaseRef2.child(getTrackID).setValue(upload);
                        Toast.makeText(getApplicationContext(), "Update successful", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getApplicationContext(), "Upload failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }

    private void openImagesActivity() {
        Intent intent = new Intent(getApplicationContext(), ImageActivity.class);
        startActivity(intent);
    }

    private void updateLabel() {
        String myFormat = "MM/dd/yy"; //In which you need put here
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);

        mTextViewDate.setText(sdf.format(myCalendar.getTime()));
    }
}