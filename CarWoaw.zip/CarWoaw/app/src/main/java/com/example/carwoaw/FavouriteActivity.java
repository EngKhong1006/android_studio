package com.example.carwoaw;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import static com.example.carwoaw.HomeFragment.EXTRA_DATE;
import static com.example.carwoaw.HomeFragment.EXTRA_ENGINE;
import static com.example.carwoaw.HomeFragment.EXTRA_MILEAGE;
import static com.example.carwoaw.HomeFragment.EXTRA_MODEL;
import static com.example.carwoaw.HomeFragment.EXTRA_OWNER;
import static com.example.carwoaw.HomeFragment.EXTRA_PRICE;
import static com.example.carwoaw.HomeFragment.EXTRA_URL;

public class FavouriteActivity extends AppCompatActivity implements FavImageAdapter.OnFavListener {

    private RecyclerView mRecyclerView;
    private FavImageAdapter mAdapter;
    private TextView favText;

    private DatabaseReference mDatabaseRef;
    private List<Upload> mUploads;
    long num = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);

        setTitle("Favourite Post");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle result2 = LoginActivity.getPw();
        String text2 = result2.getString("pw");

        mRecyclerView = findViewById(R.id.recycler_view_fav);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        mUploads = new ArrayList<>();

        mAdapter = new FavImageAdapter(getApplicationContext(), mUploads,  this);

        mRecyclerView.setAdapter(mAdapter);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("favourite").child(text2);
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                num = (dataSnapshot.getChildrenCount());
                favText = findViewById(R.id.no_fav_list);
                favText.setText("");
                if (num != 0) {
                    mUploads.clear();

                    for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                        Upload upload = postSnapshot.getValue(Upload.class);
                        mUploads.add(upload);
                    }

                    mAdapter.notifyDataSetChanged();
                } else {
                    favText.setText("No favourite post added yet!");
                    mUploads.clear();
                    mAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    public void onItemClick(int position) {
        mUploads.get(position);
        Intent intent = new Intent(getApplicationContext(), SelectedItemActivity.class);
        Upload clickedItem = mUploads.get(position);

        intent.putExtra(EXTRA_URL, clickedItem.getImageUrl());
        intent.putExtra(EXTRA_MODEL, clickedItem.getName());
        intent.putExtra(EXTRA_ENGINE, clickedItem.getEngine());
        intent.putExtra(EXTRA_MILEAGE, clickedItem.getMileage());
        intent.putExtra(EXTRA_PRICE, clickedItem.getPrice());
        intent.putExtra(EXTRA_DATE, clickedItem.getDate());
        intent.putExtra(EXTRA_OWNER, clickedItem.getOwner());

        startActivity(intent);
    }

    @Override
    public boolean onSupportNavigateUp() {
        navigateUpTo(new Intent(getBaseContext(), MainActivity.class));
        return true;
    }
}