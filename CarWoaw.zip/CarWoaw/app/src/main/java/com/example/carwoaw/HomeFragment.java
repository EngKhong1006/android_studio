package com.example.carwoaw;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class HomeFragment extends Fragment implements HomeImageAdapter.OnItemListener {
    public static final String EXTRA_URL = "imageUrl";
    public static final String EXTRA_MODEL = "carModel";
    public static final String EXTRA_ENGINE = "carEngine";
    public static final String EXTRA_MILEAGE = "carMileage";
    public static final String EXTRA_PRICE = "carPrice";
    public static final String EXTRA_DATE = "carDate";
    public static final String EXTRA_OWNER = "carOwner";
    public static final String EXTRA_POSITION = "key";
    public static final String EXTRA_CODE = "carOwnerCode";
    public static final String EXTRA_TRACK_ID = "trackingID";
    public static final String EXTRA_TYPE = "carType";
    public static final String EXTRA_POS = "position";

    private RecyclerView mRecyclerView;
    private HomeImageAdapter mAdapter;
    private Button mFav;

    private DatabaseReference mDatabaseRef;
    private List<Upload> mUploads;
    private Context mContext;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        getActivity().setTitle("CarWoaw");

        mContext = getActivity();
        setHasOptionsMenu(true);

        mFav = view.findViewById(R.id.fav_button);

        mRecyclerView = view.findViewById(R.id.recycler_view_home);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        mUploads = new ArrayList<>();

        mAdapter = new HomeImageAdapter(getContext(), mUploads, this);

        mRecyclerView.setAdapter(mAdapter);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("uploads2");

        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mUploads.clear();

                for (DataSnapshot postSnapshot : dataSnapshot.getChildren()) {
                    Upload upload = postSnapshot.getValue(Upload.class);
                    upload.setKey(postSnapshot.getKey());
                    mUploads.add(upload);
                }

                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


        return view;
    }

    @Override
    public void onItemClick(int position) {
        mUploads.get(position);
        Intent intent = new Intent(getContext(), SelectedItemActivity.class);
        Upload clickedItem = mUploads.get(position);

        intent.putExtra(EXTRA_URL, clickedItem.getImageUrl());
        intent.putExtra(EXTRA_MODEL, clickedItem.getName());
        intent.putExtra(EXTRA_ENGINE, clickedItem.getEngine());
        intent.putExtra(EXTRA_MILEAGE, clickedItem.getMileage());
        intent.putExtra(EXTRA_PRICE, clickedItem.getPrice());
        intent.putExtra(EXTRA_DATE, clickedItem.getDate());
        intent.putExtra(EXTRA_OWNER, clickedItem.getOwner());
        intent.putExtra(EXTRA_CODE, clickedItem.getCode());
        intent.putExtra(EXTRA_TRACK_ID, clickedItem.getTrackID());
        intent.putExtra(EXTRA_TYPE, clickedItem.getType());
        intent.putExtra(EXTRA_POS, clickedItem.getTypePos());

        startActivity(intent);
    }

}
