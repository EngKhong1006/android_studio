package com.example.carwoaw;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    private TextView tvName;
    private TextView tvGender;
    private TextView tvPhone;
    private TextView tvEmail;
    String getName, getEmail, getGender, getPhone, text2;

    private DatabaseReference mDatabaseRef;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        getActivity().setTitle("Profile");

        MainActivity act2 = (MainActivity) getActivity();
        Bundle result2 = act2.getPc();
        text2 = result2.getString("pw");

        tvName = view.findViewById(R.id.profile_name);
        tvGender = view.findViewById(R.id.profile_gender);
        tvPhone = view.findViewById(R.id.profile_phone);
        tvEmail = view.findViewById(R.id.profile_email);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("profile").child(text2);
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                profile pro = dataSnapshot.getValue(profile.class);
                getName = pro.getName();
                getGender = pro.getGender();
                getPhone = pro.getPhone();
                getEmail = pro.getEmail();

                tvName.setText(getName);
                tvGender.setText(getGender);
                tvPhone.setText(getPhone);
                tvEmail.setText(getEmail);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
