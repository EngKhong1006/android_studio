package com.example.carwoaw;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import static com.example.carwoaw.HomeFragment.EXTRA_CODE;
import static com.example.carwoaw.HomeFragment.EXTRA_DATE;
import static com.example.carwoaw.HomeFragment.EXTRA_ENGINE;
import static com.example.carwoaw.HomeFragment.EXTRA_MILEAGE;
import static com.example.carwoaw.HomeFragment.EXTRA_MODEL;
import static com.example.carwoaw.HomeFragment.EXTRA_OWNER;
import static com.example.carwoaw.HomeFragment.EXTRA_POS;
import static com.example.carwoaw.HomeFragment.EXTRA_PRICE;
import static com.example.carwoaw.HomeFragment.EXTRA_TRACK_ID;
import static com.example.carwoaw.HomeFragment.EXTRA_TYPE;
import static com.example.carwoaw.HomeFragment.EXTRA_URL;


public class SelectedItemActivity extends AppCompatActivity {

    public static final String EXTRA_EMAIL_TO = "emailTo";
    public static final String EXTRA_EMAIL_FROM = "emailFrom";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_IMG = "img";
    public static final String EXTRA_CODE_FORCUST = "ownerCode_forCust";

    private LinearLayout llPdf;
    private Bitmap bitmap;


    private Button mFavBtn;
    String urEmail, stat;

    private DatabaseReference mDatabaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_item);

        setTitle("View Post");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle result = LoginActivity.getUser();
        String text = result.getString("email");
        urEmail = text;

        Bundle result2 = LoginActivity.getPw();
        final String text2 = result2.getString("pw");

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("favourite").child(text2);

        Intent intent = getIntent();
        final String imageUrl = intent.getStringExtra(EXTRA_URL);
        final String carModel = intent.getStringExtra(EXTRA_MODEL);
        String carEngine = intent.getStringExtra(EXTRA_ENGINE);
        String carMileage = intent.getStringExtra(EXTRA_MILEAGE);
        String carPrice = intent.getStringExtra(EXTRA_PRICE);
        String carDate = intent.getStringExtra(EXTRA_DATE);
        final String carOwner = intent.getStringExtra(EXTRA_OWNER);
        final String carOwnerCode = intent.getStringExtra(EXTRA_CODE);
        final String getTrackID = intent.getStringExtra(EXTRA_TRACK_ID);
        final String carType = intent.getStringExtra(EXTRA_TYPE);
        final String position = intent.getStringExtra(EXTRA_POS);

        ImageView imageView = findViewById(R.id.image_view_detail);
        final TextView model = findViewById(R.id.display_model);
        final TextView engine = findViewById(R.id.display_engine);
        final TextView mileage = findViewById(R.id.display_mileage);
        final TextView price = findViewById(R.id.display_price);
        final TextView date = findViewById(R.id.display_date);
        final TextView owner = findViewById(R.id.display_owner);
        final TextView type = findViewById(R.id.display_type);
        Button email_btn = findViewById(R.id.send_email);
        mFavBtn = findViewById(R.id.favourite_button);
        Button view_btn = findViewById(R.id.view_profile);

        Picasso.get().load(imageUrl).fit().centerCrop().into(imageView);
        model.setText(carModel);
        engine.setText(carEngine + "L");
        mileage.setText(carMileage + " km");
        price.setText("RM " + carPrice);
        date.setText(carDate);
        owner.setText(carOwner);
        type.setText(carType);

        view_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ShowProfileToCust.class);
                intent.putExtra(EXTRA_CODE_FORCUST, carOwnerCode);
                startActivity(intent);
            }
        });

        email_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent emailIntent = new Intent(getApplicationContext(), Send_email.class);
                emailIntent.putExtra(EXTRA_EMAIL_TO, carOwner);
                emailIntent.putExtra(EXTRA_EMAIL_FROM, urEmail);
                emailIntent.putExtra(EXTRA_TITLE, carModel);
                emailIntent.putExtra(EXTRA_IMG, imageUrl);
                startActivity(emailIntent);
            }
        });

        mFavBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stat = "Favourite";
                Upload upload = new Upload(model.getText().toString().trim(),
                        engine.getText().toString().trim(),
                        mileage.getText().toString().trim(),
                        price.getText().toString().trim(),
                        date.getText().toString().trim(),
                        owner.getText().toString().trim(),
                        stat.trim(),
                        imageUrl,
                        carOwnerCode,
                        getTrackID,
                        type.getText().toString().trim(),
                        position)
                        ;

                String uploadId = mDatabaseRef.push().getKey();
                mDatabaseRef.child(uploadId).setValue(upload);
                Intent intent = new Intent(getApplicationContext(), FavouriteActivity.class);
                startActivity(intent);
                Toast.makeText(getApplicationContext(), "Added to favourite!", Toast.LENGTH_SHORT).show();
            }
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        navigateUpTo(new Intent(getBaseContext(), MainActivity.class));
        return true;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.share, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if(id==R.id.action_share) {
            llPdf = findViewById(R.id.linear_lay);
            bitmap = loadBitmapFromView(llPdf, llPdf.getWidth(), llPdf.getHeight());
            createPdf();
        }
        return super.onOptionsItemSelected(item);
    }

    public static Bitmap loadBitmapFromView(View v, int width, int height) {
        Bitmap b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        v.draw(c);

        return b;
    }

    private void createPdf(){
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        //  Display display = wm.getDefaultDisplay();
        DisplayMetrics displaymetrics = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        float hight = displaymetrics.heightPixels ;
        float width = displaymetrics.widthPixels ;

        int convertHighet = (int) hight, convertWidth = (int) width;

//        Resources mResources = getResources();
//        Bitmap bitmap = BitmapFactory.decodeResource(mResources, R.drawable.screenshot);

        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(convertWidth, convertHighet, 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas canvas = page.getCanvas();

        Paint paint = new Paint();
        canvas.drawPaint(paint);

        bitmap = Bitmap.createScaledBitmap(bitmap, convertWidth, convertHighet, true);

        paint.setColor(Color.BLUE);
        canvas.drawBitmap(bitmap, 0, 0 , null);
        document.finishPage(page);

        // write the document content
        String targetPdf = "/pdffromlayout.pdf";
        File filePath;
        filePath = new File(Environment.getExternalStorageDirectory().getAbsolutePath(), targetPdf);
        try {
            document.writeTo(new FileOutputStream(filePath));

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Something wrong: " + e.toString(), Toast.LENGTH_LONG).show();
        }

        // close the document
        document.close();
        Toast.makeText(this, "PDF save at " + filePath, Toast.LENGTH_LONG).show();

        openGeneratedPDF();

    }

    private void openGeneratedPDF(){
        File file = new File(Environment.getExternalStorageDirectory().getAbsolutePath(),"/pdffromlayout.pdf");
        if (file.exists())
        {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            Uri uri = Uri.fromFile(file);
            intent.setDataAndType(uri, "application/pdf");
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);

            try
            {
                startActivity(intent);
            }
            catch(ActivityNotFoundException e)
            {
                Toast.makeText(SelectedItemActivity.this, "No Application available to view pdf", Toast.LENGTH_LONG).show();
            }
        }
    }
}