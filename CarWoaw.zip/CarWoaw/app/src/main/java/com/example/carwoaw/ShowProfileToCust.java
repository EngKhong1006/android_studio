package com.example.carwoaw;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import static com.example.carwoaw.HomeFragment.EXTRA_CODE;
import static com.example.carwoaw.SelectedItemActivity.EXTRA_CODE_FORCUST;

public class ShowProfileToCust extends AppCompatActivity {

    private TextView tvName;
    private TextView tvGender;
    private TextView tvPhone;
    private TextView tvEmail;
    private Button callBtn;
    String getName, getEmail, getGender, getPhone, text2;

    private DatabaseReference mDatabaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_profile_to_cust);

        Intent intent = getIntent();
        text2 = intent.getStringExtra(EXTRA_CODE_FORCUST);

        tvName = findViewById(R.id.show_profile_name);
        tvGender = findViewById(R.id.show_profile_gender);
        tvPhone = findViewById(R.id.show_profile_phone);
        tvEmail = findViewById(R.id.show_profile_email);

        mDatabaseRef = FirebaseDatabase.getInstance().getReference().child("profile").child(text2);
        mDatabaseRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                profile pro = dataSnapshot.getValue(profile.class);
                getName = pro.getName();
                getGender = pro.getGender();
                getPhone = pro.getPhone();
                getEmail = pro.getEmail();

                tvName.setText(getName);
                tvGender.setText(getGender);
                tvPhone.setText(getPhone);
                tvEmail.setText(getEmail);

                setTitle("Owner Profile");
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(getApplicationContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}