package com.example.carwoaw;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.Timer;
import java.util.TimerTask;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    //Button logout;

    private DrawerLayout drawer;
    private TextView mSaved_email;
    private View mView;
    static String emailToDB;
    static String pcToDB;
    private Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setTitle("CarWoaw");

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        mView = navigationView.getHeaderView(0);
        mSaved_email = (TextView) mView.findViewById(R.id.saved_email);

        Bundle result = LoginActivity.getUser();
        String text = result.getString("email");
        mSaved_email.setText(text);
        emailToDB = text;

        Bundle result2 = LoginActivity.getPw();
        String text2 = result2.getString("pw");
        pcToDB = text2;

        navigationView.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawer, toolbar,
                R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
            navigationView.setCheckedItem(R.id.nav_home);
        }
    }

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            switch (menuItem.getItemId()) {

                case R.id.nav_home:
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
                    break;

                case R.id.nav_profile:
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new ProfileFragment()).commit();
                    break;

                case R.id.nav_logout:
                    AlertDialog alertDialog = new AlertDialog.Builder(this)
                            .setIcon(R.drawable.ic_sharp_warning)
                            .setTitle("Are you sure to logout?")
                            .setMessage("Please remember your username and password!")
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    FirebaseAuth.getInstance().signOut();
                                    startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                                    Toast.makeText(getApplicationContext(), "You have logged out!", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Toast.makeText(getApplicationContext(), "Logout action cancelled!", Toast.LENGTH_SHORT).show();
                                }
                            })
                            .show();
                    break;

                case R.id.nav_add:
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new AddFragment()).commit();
                    break;

                case R.id.nav_edit:
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new EditFragment()).commit();
                    break;
                case R.id.nav_fav:
                    getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new FavFragment()).commit();
                    break;
                case  R.id.nav_bin:
                    Intent intent = new Intent(getApplicationContext(), RecycleBin.class);
                    startActivity(intent);
                    break;
            }
            drawer.closeDrawer(GravityCompat.START);
            return true;
        }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    public static Bundle getUser() {
        Bundle b = new Bundle();
        b.putString("email", emailToDB);
        return b;
    }

    public static Bundle getPc() {
        Bundle b = new Bundle();
        b.putString("pw", pcToDB);
        return b;
    }

    @Override
    protected void onPause() {
        super.onPause();

        timer = new Timer();
        Log.i("Main", "Invoking logout timer");
        LogOutTimerTask logoutTimeTask = new LogOutTimerTask();
        timer.schedule(logoutTimeTask, 300000); //auto logout in 5 minutes
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (timer != null) {
            timer.cancel();
            Log.i("Main", "cancel timer");
            timer = null;
        }
    }

    private class LogOutTimerTask extends TimerTask {

        @Override
        public void run() {

            //redirect user to login screen
            Intent i = new Intent(MainActivity.this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(i);
            Toast.makeText(getApplicationContext(), "Due to inactivity you have been sign out!", Toast.LENGTH_LONG).show();
            finish();
        }
    }
}